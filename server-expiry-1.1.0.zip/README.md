### **Thanks for purchasing!**



We do provide a documentation website for instructions in installing this extension, please visit [https://docs.axtonbuilds.xyz/pterodactyl-extensions/server-expiry.html](https://docs.axtonbuilds.xyz/pterodactyl-extensions/server-expiry.html) for more details.

